# Direct Print Server

Print directly from Android to the printer on your PC.

Android Print Service
https://play.google.com/store/apps/details?id=com.solvaig.printservice
